print("__main__ invoked")
