def my_function():
    print("my_function was successfully invoked!")

print("Module my_lib was imported or executed.")